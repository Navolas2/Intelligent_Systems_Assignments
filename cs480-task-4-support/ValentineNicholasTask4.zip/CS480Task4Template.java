import java.util.ArrayList;

import cs480viewer.task5.Agent;
import cs480viewer.task5.AgentManager;
import cs480viewer.task5.E_TrackMode;
import cs480viewer.task5.Viewer;

//=============================================================================================================================================================
public class CS480Task4Template
{
   // ---------------------------------------------------------------------------------------------------------------------------------------------------------
   public static void main(final String[] args)
   {
      new CS480Task4Template();
   }

   private final Viewer _viewer;

   // ---------------------------------------------------------------------------------------------------------------------------------------------------------
   public CS480Task4Template()
   {
      _viewer = new Viewer("task4_3.trk", 0);

      doTest1();
   }

   // ---------------------------------------------------------------------------------------------------------------------------------------------------------
   private void doTest1()
   {
      // this block provides control over displaying individual tracks; use the T key to toggle all on and off simultaneously. It applies to record mode only;
      // your settings are not retained for grading
      // {
      AgentManager agentManager = _viewer.getAgentManager();

      Agent agentBlimpActual = agentManager.getAgent("blimp-actual");
      Agent agentBlimpBelieved = agentManager.getAgent("blimp-believed");

      agentBlimpActual.setTrackMode(E_TrackMode.HORIZONTAL);
      agentBlimpBelieved.setTrackMode(E_TrackMode.HORIZONTAL);
      // }
      point s1 = new point(0,0,-500);
      point s2 = new point(-500,0,500);
      point s3 = new point(500,0,500);
      point s4 = new point(0,0,500);
      blimp b = new blimp(new point(-200, 0, (Math.random() * 60)-30 - 200));
      b.main = true;
      blimp proper = new blimp(new point(-200, 0, -200));
      _viewer.doAddEvent("station1", s1.x, s1.y, s1.z, 0, 0, 0);
      _viewer.doAddEvent("station2", s2.x, s2.y, s2.z, 0, 0, 0);
      RayFactory station1 = new RayFactory(s1, 5, b);
      RayFactory station2 = new RayFactory(s2, 5, b);
      RayFactory station3 = new RayFactory(s3, 5, b);
      RayFactory station4 = new RayFactory(s4, 5, b);

      ArrayList<ray[]> ray1 = new ArrayList<ray[]>();
      ArrayList<ray[]> ray2 = new ArrayList<ray[]>();
      ArrayList<ray[]> ray3 = new ArrayList<ray[]>();
      ArrayList<ray[]> ray4 = new ArrayList<ray[]>();
      for (int i = 0; i < 3000; i += 5)
      {
    	  station1.setTarget(b);
    	  station2.setTarget(b);
    	  station3.setTarget(b);
    	  station4.setTarget(b);
    	  runRays(ray1, "r1", "ray1", station1, b);
    	  runRays(ray2, "r2", "ray2", station2, b);
    	  runRays(ray3, "r2", "ray2", station3, b);
    	  runRays(ray4, "r1", "ray1", station4, b);
    	  
    	  proper.copyData(b);
    	  point[] bpoint = b.nextLocation();
    	  point[] ppoint = proper.nextLocation();
         _viewer.doAddEvent("blimp-actual", ppoint[0].x, ppoint[0].y, ppoint[0].z, ppoint[1].z, 0, 0);
         _viewer.doAddEvent("blimp-believed", bpoint[0].x, bpoint[0].y, bpoint[0].z, bpoint[1].z, 0, 0);


         _viewer.doAdvanceEventClock();
      }
   }
   
   private ArrayList<ray[]> runRays(ArrayList<ray[]> ray, String rayList, String viewerName, RayFactory station, blimp b)
   {
	   
	   ArrayList<point[]> rayTwo = new ArrayList<point[]>();
 	  if (ray.size() > 0)
 	  {
 		  for (int k = 0; k < ray.size(); k++)
 		  {
 			  ray.set(k, station.raysNextLocation(ray.get(k)));
 			  if(ray.get(k) == null)
 			  {
 				  ray.remove(k);
 				  k--;
 			  }
 		  }
 	  }
 	  ray.add(station.nextRay());
 	  for(int k = 0; k < ray.size(); k++)
 	  {
 		  point[] p = new point[ray.get(k).length];
 		  p = station.nextLocations(ray.get(k));
 		  if(!b.hasRay(rayList)){b.collisionCheckLocal(ray.get(k), rayList);}
 		  rayTwo.add(p);
 		  for(int l = 0; l < p.length; l++)
 		  {
 			  if (k == 0 && l == 0)
 			  {
 				  //_viewer.doAddEvent(viewerName, p[l].x, p[l].y, p[l].z, 0, 0, 0);
 			  }
 		  }
 	  }
 	  return ray;
   }
}
