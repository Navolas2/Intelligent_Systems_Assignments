import java.util.ArrayList;


public class genericMovement {
	point heading;
	point current;
	protected int count;
	protected double turn;
	protected boolean right;
	protected double turnInc = 10;
	protected double speed = 5;
	protected String name;
	
	public genericMovement ()
	{
		name = "";
		double x = Math.random() * 2;
		if (x > 1){x -= 1; x = x *-1;}
		double y = 0;
		double z = Math.random() * 2;
		if (z > 1){z -= 1; z = z *-1;}
		heading = new point(x,y,z);
		heading.changeLength(speed);
		newCount();
		x = (Math.random() * 800);
		if (x > 400){x -= 400; x = x *-1;}
		y = 0;
		z = (Math.random() * 800);
		if (z > 400){z -= 400; z = z *-1;}
		turn = 0;
		current = new point(x, y, z);
	}
	
	public void setName(String name)
	{
		this.name = name;
	}
	
	public point[] nextLocation()
	{
		if (count <= 0 && turn == 0){
			newHeading();
		}
		if (turn != 0){turn();}
		else{heading.changeLength(speed);}
		point nloc = current.add(heading);
		
		if (nloc.boundcheck (400, -400, 200,-200, 400, -400))
		{
			count -= 2;
		}
		else{
			count--;
		}
		if (nloc.boundcheck (400, -400, 200,-200, 400, -400) && turn == 0 && checkHeading())
		{
			flipHeading();
			nloc = current.add(heading);
		}
		point rot = new point(heading);
		rot.convertRotation();
		current = nloc;
		point [] ret = {current, rot};
		return ret;
	}

	protected boolean checkHeading() {
		point nloc = current.add(heading);
		boolean out = true;
		int i = 0;
		while (out && i < 20){
			out = nloc.boundcheck(400, -400, 200,-200, 400, -400);
			nloc = nloc.add(heading);
			i++;
		}
		return out;
	}

	protected void turn() {
		if (turn > turnInc || (turn * -1) > turnInc)
		{
			if (right){
				heading.rotateY(turnInc * -1);
			}
			else{
				heading.rotateY(turnInc);	
			}
			if (turn < 0)
			{
				turn += turnInc;
			}
			else
			{
				turn -= turnInc;
			}
		}
		else
		{
			heading.rotateY(turn);
			turn = 0;
		}
		heading.changeLength(speed * .75);
	}

	protected void flipHeading() {
		double rot = Math.random() - .5;
		right = (.5 > Math.random());
		//rot = 0;
		rot = Math.acos(rot);
		rot = Math.toDegrees(rot);
		turn = rot;
		turn();
		//heading.rotateY(rot);
		newCount();
	}

	protected void newHeading() {
		double rot = (Math.random() * 2) - 1;
		right = (.5 > Math.random());
		rot = Math.acos(rot);
		rot = Math.toDegrees(rot);
		if (right){rot *= -1;}
		turn = rot;
		//heading.rotateY(rot);
		turn();
		newCount();
	}
	
	protected void newCount(){
		count = (int) (Math.random() * 15) + 5;
		count = 20;
	}
	
	protected void changeCount(int i) {
		if (i != -1){count = i;}
	}
	
	public boolean seeObject(point p, double d, double a)
	{
		if (current.distance(p) <= d)
		{
			point nLoc = current.add(heading);
			point p2 = new point(p, current);
			double angle = nLoc.angle(current, p2);
			if (angle < 0){
				angle *= -1;
				}
			if (angle <= a)
			{
				return true;
			}
		}
		return false;
	}
	
	public static void collisionCheck(ArrayList<genericMovement> points)
	{
		for(int i = 0; i < points.size(); i++)
		{
			for (int j = i+1; j < points.size(); j++)
			{				
				genericMovement p1 = points.get(i);
				genericMovement p2 = points.get(j);
				point move1 = p1.current;
				point move2 = p2.current;
				
				double d = move1.distance(move2);
				double d2 = p1.nextDistance(p2);
				if (d <= 50 && d >= d2)
				{
					if (p1.name.equals(p2.name))
					{
						if (!p1.name.equals("happyBee"))
						{
							p1.newHeading();
							p2.newHeading();
						}
					}
					else if(p1.name.equals("scout"))
					{
						p1.newHeading();
					}
					else if(p2.name.equals("scout"))
					{
						p2.newHeading();
					}
				}
			}
		}
	}
	
	protected double nextDistance(genericMovement p2) {
		point next = current.add(heading);
		point next2 = p2.current.add(p2.heading);
		return next.distance(next2);
	}
	
	public void collisionCheckLocal(ArrayList<genericMovement> objects)
	{
		//This method is only for overloading
	}
	
	public void collisionCheckLocal(genericMovement[] objects, String r)
	{
		//This method is only for overloading
	}

	public void setHeading(genericMovement genericMovement) {
		heading = new point(genericMovement.current, this.current);
		heading.changeLength(speed);
	}
}
