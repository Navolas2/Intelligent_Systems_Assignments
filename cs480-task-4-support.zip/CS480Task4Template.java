import cs480viewer.task5.Agent;
import cs480viewer.task5.AgentManager;
import cs480viewer.task5.E_TrackMode;
import cs480viewer.task5.Viewer;

//=============================================================================================================================================================
public class CS480Task4Template
{
   // ---------------------------------------------------------------------------------------------------------------------------------------------------------
   public static void main(final String[] args)
   {
      new CS480Task4Template();
   }

   private final Viewer _viewer;

   // ---------------------------------------------------------------------------------------------------------------------------------------------------------
   public CS480Task4Template()
   {
      _viewer = new Viewer("/home/dtappan/task4_1.trk", 0);

      doTest1();
   }

   // ---------------------------------------------------------------------------------------------------------------------------------------------------------
   private void doTest1()
   {
      // this block provides control over displaying individual tracks; use the T key to toggle all on and off simultaneously. It applies to record mode only;
      // your settings are not retained for grading
      // {
      AgentManager agentManager = _viewer.getAgentManager();

      Agent agentBlimpActual = agentManager.getAgent("blimp-actual");
      Agent agentBlimpBelieved = agentManager.getAgent("blimp-believed");

      agentBlimpActual.setTrackMode(E_TrackMode.HORIZONTAL);
      agentBlimpBelieved.setTrackMode(E_TrackMode.HORIZONTAL);
      // }

      _viewer.doAddEvent("station1", 0, 0, -500, 0, 0, 0);
      _viewer.doAddEvent("station2", -500, 0, 500, 0, 0, 0);

      for (int i = 0; i < 200; i += 5)
      {
         _viewer.doAddEvent("blimp-actual", -200 + i, 0, -200, 90, 0, 0);
         _viewer.doAddEvent("blimp-believed", -200 + i, 0, -170, 90, 0, 0);

         _viewer.doAddEvent("ray1", 300 - i, 0, 300, 0, 0, 0);
         _viewer.doAddEvent("ray2", -300 + i, 0, -300, 0, 0, 0);

         _viewer.doAdvanceEventClock();
      }
   }
}
